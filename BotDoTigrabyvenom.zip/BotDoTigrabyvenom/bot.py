############################
 # BY: @VENOMPCX | @LEVELUPCENTER
#### SE POSTAR DEIXA OS CRÉDITOS ###

import os
import json
import random
from datetime import datetime, timedelta
from pyrogram import Client
import schedule
import time

def load_config(file_path):
    with open(file_path, "r") as config_file:
        config = json.load(config_file)
    return config


def generate_signal():
    n_jogadas = random.randint(1, 13)
    validade = datetime.now() + timedelta(minutes=5)
    validade_str = validade.strftime("%Y-%m-%d %H:%M:%S")
    return n_jogadas, validade_str


def format_signal_message(jogadas, validade, link_plataforma):
    message = f"✅ OPORTUNIDADE IDENTIFICADA\n\n🐯 Fortune Tiger\n🔥 Nº de Jogadas: {jogadas}\n⏰ Validade: {validade}\n\n👉🏻 ENTRE AGORA NO JOGO {link_plataforma} 👈🏻"
    return message

# Função para enviar o sinal para o grupo
def send_signal_to_group():
    if "group_id" in config:
        n_jogadas, validade = generate_signal()
        link_plataforma = "https://www.xvideos.com"  # Substitua pelo link real da plataforma
        signal_message = format_signal_message(n_jogadas, validade, link_plataforma)
        app.send_message(config["group_id"], signal_message)
current_directory = os.path.abspath(os.path.dirname(__file__))

# Definindo o caminho para o arquivo de configuração
CONFIG_FILE = os.path.join(current_directory, "config", "config.json")

# Carregando as configurações
config = load_config(CONFIG_FILE)

# Criando uma instância do bot com as configurações
app = Client("my_bot", api_id=config["api_id"], api_hash=config["api_hash"], bot_token=config["bot_token"])

# Agendando o envio do sinal a cada 10 minutos (ou ajuste o intervalo como desejar)
schedule.every(10).minutes.do(send_signal_to_group)


while True:
    schedule.run_pending()
    time.sleep(1)

app.run()
