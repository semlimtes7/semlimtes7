import gerar_cobranca
import json
import telebot
import requests
import mercadopago
import time
import datetime
import random
from datetime import timezone
from pytz import timezone
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
from smsactivate.api import SMSActivateAPI
from gerencianet import Gerencianet
from credenciais import CREDENTIALS

def api_sms():
    with open('settings/credenciais.json', 'r') as f:
        data = json.load(f)
    return data["api-sms"]
sms = SMSActivateAPI(str(api_sms()))
gn = Gerencianet(CREDENTIALS)
class ConverterMoeda:
    def conversao(quantidade):
        valor_rublo = f'{float(requests.get("https://economia.awesomeapi.com.br/last/RUB-BRL").json()["RUBBRL"]["high"]):.3f}'
        return f'{float(quantidade) * float(valor_rublo)}'
class InfoApi:
    def comparativo(entrada):
        u = sms.getTopCountriesByService(f'{entrada}')
        data = []
        paises_ja_foram = []
        with open('infosms/paises.json', 'r') as f:
            arquivo = json.load(f)
        paises_disponiveis = []
        for paises_disp in arquivo["pais"]:
            paises_disponiveis.append(str(paises_disp["id"]))
        for servico in u:
            for opcao in u[f"{servico}"]:
                country = u[f"{servico}"]["country"]
                price = u[f"{servico}"]["price"]
                if str(country) in paises_disponiveis:
                    if country not in paises_ja_foram:
                        paises_ja_foram.append(country)
                        data.append({"pais": country, "valor": price})
                    else:
                        pass
                pass
        lista_ordenada = sorted(data, key=lambda x: x["valor"])[:20]
        response = []
        for oferta in lista_ordenada:
            try:
                pais_id = oferta["pais"]
                pais = InfoApi.pegar_pais(pais_id)
                valor = InfoApi.pegar_servico(pais_id, str(entrada))
                valor = valor["valor"]
                if str(pais_id) == '73':
                    with open('settings/substituir_valor.json', 'r') as f:
                        data = json.load(f)
                    for servico_mod in data["servicos"]:
                        if str(id) == servico_mod["id"]:
                            valor = float(servico_mod["valor"])
                            break
                        pass
                response.append({"id": pais_id, "pais": pais, "valor": float(valor)})
            except Exception as e:
                print(e)
        return response
    def api_sms():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return data["api-sms"]
    def porcentagem_lucro():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return data["porcentagem-lucro"]
    def mudar_porcentagem_lucro(porcent):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["porcentagem-lucro"] = porcent
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
    def saldo_api():
        saldo = sms.getBalance()
        return saldo
    def operadoras():
        lista = ['claro', 'oi', 'tim', 'vivo']
        return lista
    def mudar_nomes_servicos(nome):
        if nome.startswith('clubhouse'):
            return 'ClubHouse'
        elif nome.startswith('carousell'):
            return 'Carousell'
        elif nome.startswith('baidu'):
            return 'Baidu'
        elif nome.startswith('dostavista'):
            return 'DostaVista'
        elif nome.startswith('mocospace'):
            return 'MocoSpace'
        elif nome.startswith('microsoftmicro'):
            return 'Microsoft'
        elif nome.startswith('apple'):
            return 'Apple'
        elif nome.startswith('yalla'):
            return 'Yallah'
        elif nome.endswith('vk'):
            return 'VK'
        elif nome.endswith('.ru'):
            return 'classmatesok.ru'
        elif nome.startswith('olx'):
            return 'Olx'
        elif nome.startswith('Didi'):
            return 'Didi'
        elif 'other' in nome.split():
            return 'Outros'
        else:
            return None
    def servicos(pais, operadora:str|None=None):
        lista = []
        lsdd = sms.getRentServicesAndCountries(country=str(pais))
        ls = lsdd["services"]
        porcentagem_lucro = float(InfoApi.porcentagem_lucro())
        cotacao_rublo1 = f'{float(requests.get("https://economia.awesomeapi.com.br/last/RUB-BRL").json()["RUBBRL"]["high"]):.3f}'
        cotacao_rublo = float(cotacao_rublo1)
        for serv in ls:
            id = serv
            custo = ls[serv]["cost"]
            custo_real1 = float(custo) * float(cotacao_rublo)
            custo_real = f'{float(custo_real1):.2f}'
            search_name = ls[serv]["search_name"]
            name = search_name.split(',')[0].split('/')[0].split('+')[0]
            name_teste = InfoApi.mudar_nomes_servicos(name.lower())
            if name_teste == None:
                name = name
            else:
                name = name_teste
            valor = float(custo_real) * float(porcentagem_lucro) / 100
            valor = f'{float(valor + float(custo_real)):.2f}'
            if str(pais) == '73':
                with open('settings/substituir_valor.json', 'r') as f:
                    data = json.load(f)
                for servico_mod in data["servicos"]:
                    if id == servico_mod["id"]:
                        valor = float(servico_mod["valor"])
                        break
                    pass
            servico = {"id": id, "nome": name, "valor": valor}
            lista.append(servico)
        return lista
    def pegar_servico(pais, id):
        servico = None
        ls = sms.getRentServicesAndCountries(country=str(pais))
        porcentagem_lucro = InfoApi.porcentagem_lucro()
        cotacao_rublo1 = f'{float(requests.get("https://economia.awesomeapi.com.br/last/RUB-BRL").json()["RUBBRL"]["high"]):.3f}'
        cotacao_rublo = float(cotacao_rublo1)
        for serv in ls["services"]:
            if str(serv) == str(id):
                id = serv
                custo = ls["services"][f"{serv}"]["cost"]
                search_name = ls["services"][f"{serv}"]["search_name"]
                name1 = search_name.split(',')[0].split('/')[0].split('+')[0]
                name = InfoApi.mudar_nomes_servicos(name1.lower())
                if name == None:
                    name = name1
                custo_real1 = float(custo) * float(cotacao_rublo)
                custo_real = f'{float(custo_real1):.2f}'
                valor = float(custo_real) * float(porcentagem_lucro) / 100
                valor = f'{float(valor + float(custo_real)):.2f}' 
                info_servico2 = sms.getPrices(id, pais)[f"{pais}"]
                info_servico1 = info_servico2[f"{id}"]
                count = info_servico1["count"]
                if str(pais) == '73':
                    with open('settings/substituir_valor.json', 'r') as f:
                        data = json.load(f)
                    for servico_mod in data["servicos"]:
                        if id == servico_mod["id"]:
                            valor = float(servico_mod["valor"])
                            break
                        pass
                servico = {"id": id, "nome": name, "valor": valor, "count": count}
                return servico
            else:
                pass
        return False
    def listar_pais():
        with open('infosms/paises.json', 'r') as f:
            data = json.load(f)
        return data["pais"]
    def pegar_pais(id):
        with open('infosms/paises.json', 'r') as f:
            data = json.load(f)["pais"]
        for pais in data:
            if str(pais["id"]) == str(id):
                return pais["pais"]
            else:
                pass
        return False
    def comprar_numero(servico, pais, operadora:str|None=None):
        info_servico2 = sms.getPrices(servico, pais)[f"{pais}"]
        info_servico1 = info_servico2[f"{servico}"]
        if str(info_servico1["count"]) != '0':
            id_servico = servico
            valor = info_servico1["cost"]
            estoque = info_servico1["count"]
            if int(estoque) != 0:
                try:
                    compra = sms.getNumberV2(id_servico, operator=operadora, country=pais)
                    response = {"id": compra["activationId"], "numero": compra["phoneNumber"], "operadora": compra["activationOperator"]}
                    return response
                except:
                    print(compra)
                    print(f"Valor do serviço: {valor} | Seu saldo: {sms.getBalance()['balance']}")
                    return False
        else:
            return False
    def pegar_status_numero(id):
        status = sms.getStatus(id)
        if type(status) == str:
            if status == 'STATUS_CANCEL':
                    return False
            elif status == 'STATUS_WAIT_CODE':
                return 'Aguardando SMS...'
            elif status.split(':')[0] == 'STATUS_WAIT_RETRY':
                return f'Aguardando esclarecimento do código...'
            elif status == 'STATUS_WAIT_RESEND':
                return 'Aguardando o envio de sms novamente...'
            elif status.split(':')[0] == 'STATUS_OK':
                codigo = status.split(':')[1]
                if codigo == None:
                    return "Aguardando código..."
                else:
                    return f'<b>Novo código:</b> <code>{codigo}</code>'
        else:
            if status["error"] == 'STATUS_CANCEL':
                return False
    def mudar_status_numero(id, status):
        {
            "1": "informar sobre a prontidão do número (SMS enviado para o número)",
            "3": "Solicite outro código (gratuito)",
            "6": "Ativação completa",
            "8": "informar que o número foi utilizado e cancelar a ativação"
        }
        mudanca = sms.setStatus(id=str(id), status=str(status))
        return mudanca
class ApiGnInfo():
    def saldo():
        response =  gn.pix_list_balance()
        saldo = response["saldo"]
        return f'{float(saldo):.2f}'
    def extrato():
        data_atual = datetime.datetime.now()
        fuso_horario = timezone('America/Sao_Paulo')
        data_de_hoje = data_atual.astimezone(fuso_horario)
        data_fim = data_de_hoje.strftime('%Y-%m-%d')
        data_inicio = data_de_hoje.strftime('%Y-%m-01')
        params = {
        "inicio": f"{data_inicio}T21:00:00Z",
        "fim": f"{data_fim}T20:59:00Z"
        }
        response =  gn.pix_list_charges(params=params)
        return response
    def pix_gerados():
        response = ApiGnInfo.extrato()
        quantity = 0
        for cobranca in response["cobs"]:
            if cobranca["status"] != 'CONCLUIDA':
                quantity += 1
        return quantity
    def pix_pagos():
        response = ApiGnInfo.extrato()
        quantity = 0
        for cobranca in response["cobs"]:
            if cobranca["status"] == 'CONCLUIDA':
                quantity += 1
        return quantity
    def txt_detalhado_pix_gerados():
        response = ApiGnInfo.extrato()
        ord_limpa = []
        for cobranca in response["cobs"]:
            if cobranca["status"] != 'CONCLUIDA':
                ord_limpa.append(cobranca)
        texto = 'ÚLTIMOS 10 PIX GERADOS NA SUA CONTA GN\n\n'
        for cobranca in ord_limpa[:10]:
            horario_gerado = cobranca["calendario"]["criacao"]
            valor = cobranca["valor"]["original"]
            id_pag = cobranca["txid"]
            texto += f'Valor: R${valor}\nData: {horario_gerado}\nTransation ID: {id_pag}\n\n\n'
        with open('pix_gerados_gn.txt', 'w') as f:
            f.write(texto)
        return 'pix_gerados_gn'
    def txt_detalhado_pix_pagos():
        response = ApiGnInfo.extrato()
        ord_limpa = []
        for cobranca in response["cobs"]:
            if cobranca["status"] == 'CONCLUIDA':
                ord_limpa.append(cobranca)
        texto = 'ÚLTIMOS 10 PIX PAGOS NA SUA CONTA GN\n\n'
        for cobranca in ord_limpa[:10]:
            try:
                if cobranca["loc"]["tipoCob"] == 'cob':
                    gerado_pela_api = 'Sim'
                else:
                    gerado_pela_api = 'Não'
            except:
                gerado_pela_api = 'Não'
            horario_gerado = cobranca["calendario"]["criacao"]
            valor = cobranca["valor"]["original"]
            id_pag = cobranca["txid"]
            texto += f'Valor: R${valor}\nData: {horario_gerado}\nTransation ID: {id_pag}\nGerado pela api: {gerado_pela_api}\n\n\n'
        with open('pix_pagos_gn.txt', 'w') as f:
            f.write(texto)
        return 'pix_pagos_gn'
class ViewTime():
    def data_atual():
        data_atual = datetime.datetime.now()
        fuso_horario = timezone('America/Sao_Paulo')
        data_sao_paulo = data_atual.astimezone(fuso_horario)
        data_em_texto = data_sao_paulo.strftime('%d/%m/%Y')
        return data_em_texto
    def hora_atual():
        data_e_hora_atuais = datetime.datetime.now()
        fuso_horario = timezone('America/Sao_Paulo')
        data_e_hora_sao_paulo = data_e_hora_atuais.astimezone(fuso_horario)
        hora_sao_paulo_em_texto = data_e_hora_sao_paulo.strftime('%H:%M:%S')
        hora_sao_paulo = datetime.datetime.strptime(hora_sao_paulo_em_texto, '%H:%M:%S').time()
        return hora_sao_paulo
class MetricasVendas():
    def total():
        with open('database/users.json', 'r') as f:
            data = json.load(f)["users"]
        receita = 0
        gasto = 0
        for user in data:
            for compra in user["compras"]:
                receita += float(compra["valor"])
                valor = float(compra["valor"])
                per = float(InfoApi.porcentagem_lucro())
                soma = valor - (valor * per / 100)
                gasto += soma
        return {"receita": f'{float(receita):.2f}', "gasto": f'{float(gasto):.2f}'}
    def trinta():
        with open('database/users.json', 'r') as f:
            data = json.load(f)["users"]
        receita = 0
        gasto = 0
        for user in data:
            for compra in user["compras"]:
                data_compra = compra["data"].split(' ')[0]
                data_atual = datetime.datetime.now()
                fuso_horario = timezone('America/Sao_Paulo')
                data_sao_paulo = data_atual.astimezone(fuso_horario)
                data_em_texto = data_sao_paulo.strftime('%d/%m/%Y')
                dia_de_hoje = datetime.datetime.strptime(data_em_texto, '%d/%m/%Y')
                dia_comprado = datetime.datetime.strptime(data_compra, '%d/%m/%Y')
                if (dia_de_hoje - dia_comprado).days < 30:
                    receita += float(compra["valor"])
                    valor = float(compra["valor"])
                    per = float(InfoApi.porcentagem_lucro())
                    soma = valor - (valor * per / 100)
                    gasto += soma
        return {"receita": f'{float(receita):.2f}', "gasto": f'{float(gasto):.2f}'}
    def sete():
        with open('database/users.json', 'r') as f:
            data = json.load(f)["users"]
        receita = 0
        gasto = 0
        for user in data:
            for compra in user["compras"]:
                data_compra = compra["data"].split(' ')[0]
                data_atual = datetime.datetime.now()
                fuso_horario = timezone('America/Sao_Paulo')
                data_sao_paulo = data_atual.astimezone(fuso_horario)
                data_em_texto = data_sao_paulo.strftime('%d/%m/%Y')
                dia_de_hoje = datetime.datetime.strptime(data_em_texto, '%d/%m/%Y')
                dia_comprado = datetime.datetime.strptime(data_compra, '%d/%m/%Y')
                if (dia_de_hoje - dia_comprado).days < 7:
                    receita += float(compra["valor"])
                    valor = float(compra["valor"])
                    per = float(InfoApi.porcentagem_lucro())
                    soma = valor - (valor * per / 100)
                    gasto += soma
        return {"receita": f'{float(receita):.2f}', "gasto": f'{float(gasto):.2f}'}
    def hoje():
        with open('database/users.json', 'r') as f:
            data = json.load(f)["users"]
        receita = 0
        gasto = 0
        for user in data:
            for compra in user["compras"]:
                data_compra = compra["data"].split(' ')[0]
                data_atual = datetime.datetime.now()
                fuso_horario = timezone('America/Sao_Paulo')
                data_sao_paulo = data_atual.astimezone(fuso_horario)
                data_em_texto = data_sao_paulo.strftime('%d/%m/%Y')
                dia_de_hoje = datetime.datetime.strptime(data_em_texto, '%d/%m/%Y')
                dia_comprado = datetime.datetime.strptime(data_compra, '%d/%m/%Y')
                if dia_de_hoje == dia_comprado:
                    receita += float(compra["valor"])
                    valor = float(compra["valor"])
                    per = float(InfoApi.porcentagem_lucro())
                    soma = valor - (valor * per / 100)
                    gasto += soma
        return {"receita": f'{float(receita):.2f}', "gasto": f'{float(gasto):.2f}'}
class CredentialsChange():
    def user_bot():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return str(data["user_bot"])
    def mudar_user_bot(user):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["user_bot"] = str(user)
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
    def token_bot():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return str(data["api-bot"])
    def mudar_token_bot(token):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["api-bot"] = str(token)
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
    def mudar_versao_bot(version):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["version"] = version
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
    def verificar_premium():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
            return data["premium"]
    def separador():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return str(data["separador"])
    def mudar_separador(separador):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["separador"] = separador
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
    def status_manutencao():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        if data["maintance"] == 'on':
            return True
        else:
            return False
    def mudar_status_manutencao():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        if data["maintance"] == "on":
            data["maintance"] = "off"
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
                return
        else:
            data["maintance"] = "on"
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
                return
    def id_dono():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        dono_id = data["id_dono"]
        return int(dono_id)
    def mudar_dono(id: str|int):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["id_dono"] = int(id)
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
    class PlataformaPix():
        def status_gn():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if data["status-pix-gn"] == True:
                return True
            else:
                return False
        def status_mp():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if data["status-pix-mp"] == True:
                return True
            else:
                return False
        def mudar_status_mp():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if data["status-pix-mp"] == False:
                data["status-pix-mp"] = True
                data["status-pix-gn"] = False
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
        def mudar_status_gn():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if data["status-pix-gn"] == False:
                data["status-pix-gn"] = True
                data["status-pix-mp"] = False
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
    class FotoMenu():
        def foto_atual():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            return data["foto-menu"]
        def mudar_foto_atual(url):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["foto-menu"] = url
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
    class SuporteInfo():
        def link_suporte():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            return str(data["link_suporte"])
        def mudar_link_suporte(link):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["link_suporte"] = str(link)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
    class StatusPix():
        def pix_manual():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if str(data["status_pix_manu"]) == 'on':
                return True
            else:
                return False
        def pix_auto():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if str(data["status_pix_auto"]) == 'on':
                return True
            else:
                return False
    class ChangeStatusPix():
        def change_pix_manual():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if str(data["status_pix_manu"]) == 'on':
                data["status_pix_manu"] = 'off'
                with open('settings/credenciais.json', 'w') as f:
                    json.dump(data, f, indent=4)
                return
            else:
                data["status_pix_manu"] = 'on'
                with open('settings/credenciais.json', 'w') as f:
                    json.dump(data, f, indent=4)
                return False
        def change_pix_auto():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            if str(data["status_pix_auto"]) == 'on':
                data["status_pix_auto"] = 'off'
                with open('settings/credenciais.json', 'w') as f:
                    json.dump(data, f, indent=4)
                return
            else:
                data["status_pix_auto"] = 'on'
                with open('settings/credenciais.json', 'w') as f:
                    json.dump(data, f, indent=4)
                return False
    class BonusPix():
        def quantidade_bonus():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            return int(data["bonus_pix"])
        def mudar_quantidade_bonus(porcentagem):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["bonus_pix"] = int(porcentagem)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
                return
        def valor_minimo_para_bonus():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            return int(data["bonus_pix_min"])
        def mudar_valor_minimo_para_bonus(valor_min):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["bonus_pix_min"] = int(valor_min)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
    class BonusRegistro():
        def bonus():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            return float(data["bonus_registro"])
        def mudar_bonus(novo_bonus):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["bonus_registro"] = float(novo_bonus)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
    class InfoPix():
        def token_mp():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            token = data["token_mp"]
            return str(token)
        def mudar_tokenmp(token):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["token_mp"] = str(token)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
            return
        def deposito_minimo_pix():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            return float(data["min_pix"])
        def trocar_deposito_minimo_pix(min):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["min_pix"] = float(min)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
                return
        def deposito_maximo_pix():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            return float(data["max_pix"])
        def trocar_deposito_maximo_pix(max):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["max_pix"] = float(max)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
                return
        def expiracao():
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            expiracao_time = data["expiracao_pix"]
            return int(expiracao_time)
        def mudar_expiracao(minutes):
            with open('settings/credenciais.json', 'r') as f:
                data = json.load(f)
            data["expiracao_pix"] = int(minutes)
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
                return True
class AfiliadosInfo():
    def status_afiliado():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        if data["afiliados"] == 'on':
            return True
        else:
            return False
    def mudar_status_afiliado():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        if data["afiliados"] == 'on':
            data["afiliados"] = "off"
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)
            return
        else:
            data["afiliados"] = "on"
            with open('settings/credenciais.json', 'w') as f:
                json.dump(data, f, indent=4)

        return
    def porcentagem_por_indicacao():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return int(data["pontos_by_indicate_buy"])
    def mudar_porcentagem_por_indicacao(pontos):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["pontos_by_indicate_buy"] = int(pontos)
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
        return
    def minimo_pontos_pra_saldo():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return data["min_points_saldo"]
    def trocar_minimo_pontos_pra_saldo(min):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["min_points_saldo"] = int(min)
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
    def multiplicador_pontos():
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        return float(data["multiplicador_pontos"])
    def trocar_multiplicador_pontos(multiplicador):
        with open('settings/credenciais.json', 'r') as f:
            data = json.load(f)
        data["multiplicador_pontos"] = float(multiplicador)
        with open('settings/credenciais.json', 'w') as f:
            json.dump(data, f, indent=4)
class Notificacoes():
    def modo_servico():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        return int(data["tipo_texto"])
    def mudar_modo_servico():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        if data["tipo_texto"] == 0:
            data["tipo_texto"] = 1
        else:
            data["tipo_texto"] = 0
        with open('settings/notify.json', 'w') as f:
            json.dump(data, f, indent=4)
    def status_notificacoes():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        if data["status_notify"] == 'on':
            return True
        else:
            return False
    def mudar_status_notificacoes():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        if data["status_notify"] == 'on':
            data["status_notify"] = 'off'
            with open('settings/notify.json', 'w') as f:
                json.dump(data, f, indent=4)
            return
        else:
            data["status_notify"] = 'on'
            with open('settings/notify.json', 'w') as f:
                json.dump(data, f, indent=4)
            return
    def id_grupo():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        return int(data["id_grupo"])
    def trocar_id_grupo(id_grupo):
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        data["id_grupo"] = int(id_grupo)
        with open('settings/notify.json', 'w') as f:
            json.dump(data, f, indent=4)
        return
    def tempo_minimo_compras():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        return int(data["time_min_compras"])
    def quantidade_de_servicos_pra_sortear():
        with open('settings/notificacao/servicos.txt', 'r') as f:
            file = f.read()
        quantidade = 0
        servicos = file.strip().split('\n')
        for servico in servicos:
            if len(servico) > 0:
                quantidade += 1
            pass
        return quantidade
    def pegar_servico_random():
        with open('settings/notificacao/servicos.txt', 'r') as f:
            file = f.read()
        file = file.splitlines()
        servico = random.choice(file)
        separar = servico.strip().split('R$')
        servico = separar[0]
        valor = separar[1]
        return servico, f'R${valor}'
    def pegar_servicos_disponiveis():
        with open('database/acessos.json', 'r') as f:
            data = json.load(f)
        nomes = []
        for acesso in data["acessos"]:
            if acesso["nome"] in nomes:
                pass
            nomes.append({"nome": acesso["nome"], "valor": acesso["valor"]})
        sort = random.choice(nomes)
        return sort["nome"], f'R${sort["valor"]:.2f}'
    def mudar_servicos_random(lista):
        with open('settings/notificacao/servicos.txt', 'w') as f:
            f.write(lista)
    def trocar_tempo_minimo_compras(min):
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        data["time_min_compras"] = int(min)
        with open('settings/notify.json', 'w') as f:
            json.dump(data, f, indent=4)
    def tempo_maximo_compras():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        return int(data["time_max_compras"])
    def trocar_tempo_maximo_compras(max):
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        data["time_max_compras"] = int(max)
        with open('settings/notify.json', 'w') as f:
            json.dump(data, f, indent=4)
    def tempo_minimo_saldo():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        return int(data["time_min_saldo"])
    def trocar_tempo_minimo_saldo(min):
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        data["time_min_saldo"] = int(min)
        with open('settings/notify.json', 'w') as f:
            json.dump(data, f, indent=4)
    def tempo_maximo_saldo():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        return int(data["time_max_saldo"])
    def trocar_tempo_maximo_saldo(max):
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        data["time_max_saldo"] = int(max)
        with open('settings/notify.json', 'w') as f:
            json.dump(data, f, indent=4)
    def min_max_saldo():
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        return float(data["saldo_min"]), float(data["saldo_max"])
    def trocar_min_max_saldo(min, max):
        with open('settings/notify.json', 'r') as f:
            data = json.load(f)
        data["saldo_min"] = int(min)
        data["saldo_max"] = int(max)
        with open('settings/notify.json', 'w') as f:
            json.dump(data, f, indent=4)
    def pegar_texto_saldo():
        with open('settings/notificacao/saldo.txt', 'r') as f:
            return f.read()
    def mudar_texto_saldo(texto):
        with open('settings/notificacao/saldo.txt', 'w') as f:
            f.write(texto)
    def pegar_texto_compra():
        with open('settings/notificacao/compra.txt', 'r') as f:
            return f.read()
    def mudar_texto_compra(texto):
        with open('settings/notificacao/compra.txt', 'w') as f:
            f.write(texto)
    def texto_notificacao_saldo():
        texto = Notificacoes.pegar_texto_saldo()
        id = random.randint(898012903, 4290812093)
        saldo_min, saldo_max = Notificacoes.min_max_saldo()
        saldo =  random.randint(int(saldo_min), int(saldo_max))
        texto = texto.replace('{id}', f'{id}').replace('{saldo}', f'{saldo}')
        return texto
    def texto_notificacao_compra():
        texto = Notificacoes.pegar_texto_compra()
        id = random.randint(898012903, 4290812093)
        if Notificacoes.modo_servico() == 0:
            servico, valor = Notificacoes.pegar_servico_random()
        else:
            servico, valor = Notificacoes.pegar_servicos_disponiveis()
        texto = texto.replace('{id}', f'{id}').replace('{servico}', f'{servico}').replace('{valor}', f'{valor}')
        return texto
bot = telebot.TeleBot(CredentialsChange.token_bot())
class Ranking():
    def SmsRecebido():
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        response = []
        processed_users = set()
        for user in data["users"]:
            if len(user["compras"]) != 0:
                compras = 0
                for compra in user["compras"]:
                    data_compra = compra["data"].split(' ')[0]
                    dateoi = datetime.datetime.now()
                    if dateoi.month == int(data_compra.split('/')[1]):
                        compras +=1
                if compras > 0 and user["id"] not in processed_users:
                    processed_users.add(user["id"])
                    nome_user = bot.get_chat(user["id"]).first_name
                    response.append({"nome": nome_user, "id": user["id"], "compras": compras})
        lista_ordenada = sorted(response, key=lambda x: -x["compras"])[:10]
        return lista_ordenada
    def Recarga():
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        response = []
        processed_users = set()
        for user in data["users"]:
            if int(user["total_pagos"]) != 0:
                valor_em_recarga = 0
                for recarga in user["pagamentos"]:
                    data_compra = recarga["data"].split(' ')[0]
                    dateoi = datetime.datetime.now()
                    if dateoi.month == int(data_compra.split('/')[1]):
                        valor_em_recarga += float(recarga["valor"])
                if valor_em_recarga > 0 and user["id"] not in processed_users:
                    processed_users.add(user["id"])
                    nome_user = bot.get_chat(user["id"]).first_name
                    response.append({"nome": nome_user, "recargas": valor_em_recarga})
        lista_ordenada = sorted(response, key=lambda x: -x["recargas"])[:10]
        return lista_ordenada
    def Gift():
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        response = []
        processed_users = set()
        for user in data["users"]:
            if len(user["gift_redeemed"]) != 0:
                valores_resgatados = 0
                for resgate in user["gift_redeemed"]:
                    data_compra = resgate["data"].split(' ')[0]
                    dateoi = datetime.datetime.now()
                    if dateoi.month == int(data_compra.split('/')[1]):
                        valores_resgatados += float(resgate["valor"])
                if valores_resgatados > 0 and user["id"] not in processed_users:
                    processed_users.add(user["id"])
                    nome_user = bot.get_chat(user["id"]).first_name
                    response.append({"nome": nome_user, "resgates": valores_resgatados})
        lista_ordenada = sorted(response, key=lambda x: -x["resgates"])[:10]
        return lista_ordenada
    def Servicos():
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        ranking_atual = {}
        for user in data["users"]:
            for compra in user["compras"]:
                if compra["servico"] not in ranking_atual:
                    ranking_atual[compra["servico"]] = 0
                ranking_atual[compra['servico']] += 1
        servicos_ordenados = sorted(ranking_atual.items(), key=lambda x: -x[1])[:10]
        return servicos_ordenados
class Alertas():
    def adicionar_alerta(id, servico):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if str(user["id"]) == str(id):
                user["alertas"].append(servico)
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
                    break
    def verificar_alerta(id, servico):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if str(user["id"]) == str(id):
                if str(servico) in user["alertas"]:
                    return True
                else:
                    return False
            pass
        return False
    def remover_alerta(id, servico):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if str(user["id"]) == str(id):
                user["alertas"].remove(servico)
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
                    break
            pass
    def usuarios_para_receber_alerta(servico):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        destinos = []
        for user in data['users']:
            if servico in user["alertas"]:
                destinos.append(user["id"])
                continue
            pass
        return destinos
    def users_com_alertas():
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        dados = []
        for user in data["users"]:
            for alerta in user["alertas"]:
                dados.append({"id": user["id"], "servico": alerta})
                continue
            pass
        return dados
class CronSaldoApi():
    def saldo_atual():
        balance_rublo = sms.getBalance()["balance"]
        valor_rublo = f'{float(requests.get("https://economia.awesomeapi.com.br/last/RUB-BRL").json()["RUBBRL"]["high"]):.3f}'
        balance_real = float(balance_rublo) * float(valor_rublo)
        return {"balance-rublo": f'{float(balance_rublo):.2f}', "balance-real": f'{float(balance_real):.2f}'}
    def saldo_minimo():
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        return data["balance"]
    def mudar_saldo_minimo(min):
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        data["balance"] = int(min)
        with open('settings/cron_saldo_api.json', 'w') as f:
            json.dump(data, f, indent=4)
    def status_aviso():
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        return data["stats"]
    def mudar_status_aviso():
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        if data["stats"] == True:
            data["stats"] = False
        elif data["stats"] == False:
            data["stats"] = True
        with open('settings/cron_saldo_api.json', 'w') as f:
            json.dump(data, f, indent=4)
    def destino_id():
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        return data["to"]
    def mudar_destino_id(id):
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        data["to"] = str(id)
        with open('settings/cron_saldo_api.json', 'w') as f:
            json.dump(data, f, indent=4)
    def tempo_aviso():
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        return data["warn-time"]
    def mudar_tempo_aviso(time):
        with open('settings/cron_saldo_api.json', 'r') as f:
            data = json.load(f)
        data["warn-time"] = time
        with open('settings/cron_saldo_api.json', 'w') as f:
            json.load(data, f, indent=4)
class InfoUser():
    def verificar_usuario(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return True
            pass
        return False
    def pix_gerados(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if str(user["id"]) == str(id):
                return int(user["pix_gerados"])
    def adicionar_pix_gerados(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if str(user["id"]) == str(id):
                user["pix_gerados"] += 1
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
    def remover_pix_gerados(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if str(user["id"]) == str(id):
                user["pix_gerados"] -= 1
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
    def novo_afiliado(usuario, indicador):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(usuario):
                if user["afiliado_por"] != 0:
                    return
                user["afiliado_por"] = int(indicador)
                break
        for user in data["users"]:
            if int(user["id"]) == int(indicador):
                if int(usuario) in user["afiliados"]:
                    return
                user["afiliacoes"] +=1
                user["afiliados"].append({"id_afiliado": int(usuario)})
                break
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
        return
    def pegar_pais_atual(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return user["pais-atual"]
            else:
                pass
        return False
    def mudar_pais_atual(id, pais):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["pais-atual"] = pais
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
                return True
            pass
        return False
    def novo_usuario(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if str(id) == str(user["id"]):
                return
            pass
        data["users"].append({"id": int(id), "banned": "False", "afiliado_por": 0, "saldo": 0, "gift_redeemed": [], "total_compras": 0, "compras": [], "total_pagos": 0, "pagamentos": [], "pontos_indicado": 0, "afiliacoes": 0, "afiliados": [], "pais-atual": '73', "alertas": []})
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
    def pegar_afiliado(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return user["afiliado_por"]
            else:
                pass
        return False
    def verificar_ban(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                if user["banned"] == 'True':
                    return True
                else:
                    return False
            pass
    def dar_ban(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["banned"] = "True"
                break
            pass
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
    def tirar_ban(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["banned"] = "False"
                break
            pass
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
    def saldo(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return float(user["saldo"])
    def add_saldo(id, novo_saldo):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["saldo"] += float(novo_saldo)
                break
            pass
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
    def tirar_saldo(id, novo_saldo):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["saldo"] -= float(novo_saldo)
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
                break
            pass
        False
    def mudar_saldo(id, novo_saldo):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["saldo"] = float(novo_saldo)
                break
            pass
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
    def gifts_resgatados(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                total = 0
                for gift in user["gift_redeemed"]:
                    total += float(gift["valor"])
                return float(total)
            pass
        return 0
    def total_compras(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return user["total_compras"]
            pass
    def total_pagos(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return user["total_pagos"]
            pass
        return False
    def pix_inseridos(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        quantity = 0.0
        for user in data["users"]:
            if int(user["id"]) == int(id):
                if len(user["pagamentos"]) > 0:
                    for pagamento in user["pagamentos"]:
                        quantity += float(pagamento["valor"])
                    pass
                pass
            pass
        return float(quantity)
    def pontos_indicacao(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return user["pontos_indicado"]
            pass
    def trocar_pontos(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                if int(user["pontos_indicado"]) >= int(AfiliadosInfo.minimo_pontos_pra_saldo()):
                    somar = int(user["pontos_indicado"]) * AfiliadosInfo.multiplicador_pontos()
                    user["pontos_indicado"] = 0
                    user["saldo"] = float(somar)
                    with open('database/users.json', 'w') as f:
                        json.dump(data, f, indent=4)
                    return True
                else:
                    return False
            pass
    def quantidade_afiliados(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                return int(user["afiliacoes"])
        return None
    def verificar_acessos_ativos(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        ativacoes_disponiveis = []
        for user in data["users"]:
            if str(user["id"]) == str(id):
                for compra in user["compras"]:
                    id_atv = compra["id_ativacao"]
                    response = InfoApi.pegar_status_numero(str(id_atv))
                    if response != None:
                        if response != False:
                            if response.startswith('Aguardan'):
                                ativacoes_disponiveis.append(compra)
        return ativacoes_disponiveis
class MudancaHistorico():
    def mudar_gift_resgatado(id, valor):
        with open('database/users.json') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["gift_redeemed"].append({"valor": float(valor), "data": f"{ViewTime.data_atual()} as {ViewTime.hora_atual()}"})
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
                break
            pass
    def add_compra(id, servico_id, valor, numero, servico, id_ativacao):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(id) == int(user["id"]):
                user["total_compras"] +=1
                user["compras"].append({"id-servico": servico_id, "valor": valor, "numero": numero, "servico": servico, "id_ativacao": id_ativacao, "data": f"{ViewTime.data_atual()} as {ViewTime.hora_atual()}"})
                break
            pass
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
    def add_pagamentos(id, valor, id_pag, valor_indicacao):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                afiliado_por = user["afiliado_por"]
                user["total_pagos"] += 1
                user["pagamentos"].append({"id_pagamento": id_pag, "valor": valor, "data": f"{ViewTime.data_atual()} as {ViewTime.hora_atual()}"})
                break
            pass
        with open('database/users.json', 'w') as f:
            json.dump(data, f, indent=4)
        if AfiliadosInfo.status_afiliado() == True and int(afiliado_por) != 0:
            with open('database/users.json', 'r') as f:
                data = json.load(f)
            for user in data["users"]:
                if int(afiliado_por) == int(user["id"]):
                    user["pontos_indicado"] += float(valor_indicacao)
                    user["saldo"] += float(valor_indicacao)
                    break
                pass
            with open('database/users.json', 'w') as f:
                json.dump(data, f, indent=4)
            return
        else:
            return
    def zerar_pontos(id):
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        for user in data["users"]:
            if int(user["id"]) == int(id):
                user["pontos_indicado"] = 0
                with open('database/users.json', 'w') as f:
                    json.dump(data, f, indent=4)
                    break
            else:
                pass
class GiftCard():
    def validar_gift(codigo):
        with open("database/gift_card.json", 'r') as f:
            data = json.load(f)
        for gift in data['gift']:
            if gift["codigo"] == codigo:
                valor = float(gift["valor"])
                return True, valor
        return False, 0
    def listar_gift():
        with open('database/gift_card.json', 'r') as f:
            data = json.load(f)
        msg = ''
        for gift in data["gift"]:
            msg += f'<code>{gift["codigo"]}</code> R${float(gift["valor"]):.2f}\n'
        return msg
    def create_gift(codigo, valor):
        with open("database/gift_card.json", 'r') as f:
            data = json.load(f)
        data["gift"].append({"codigo": codigo, "valor": float(valor)})
        with open("database/gift_card.json", 'w') as j:
            json.dump(data, j, indent=4)
        return True
    def del_gift(codigo):
        with open("database/gift_card.json", 'r') as f:
            data = json.load(f)
        for gift in data["gift"]:
            if gift["codigo"] == codigo:
                data["gift"].remove(gift)
                with open("database/gift_card.json", 'w') as f:
                    json.dump(data, f, indent=4)
                return True
            pass
        return False
class FuncaoTransmitir():
    def pegar_foto():
        with open('database/info_transmitir.json', 'r') as f:
            data = json.load(f)
            return data["photo"]
    def pegar_texto():
        with open('database/info_transmitir.json', 'r') as f:
            data = json.load(f)
            return data["texto"]
    def pegar_markup():
        with open('database/info_transmitir.json', 'r') as f:
            data = json.load(f)
            return data["markup"]
    def adicionar_foto(photo):
        with open('database/info_transmitir.json', 'r') as f:
            data = json.load(f)
        data["photo"] = photo
        with open('database/info_transmitir.json', 'w') as f:
            data = json.dump(data, f, indent=4)
    def adicionar_texto(txt):
        with open('database/info_transmitir.json', 'r') as f:
            data = json.load(f)
        data["texto"] = txt
        with open('database/info_transmitir.json', 'w') as f:
            json.dump(data, f, indent=4)
    def adicionar_markup(markup):
        with open('database/info_transmitir.json', 'r') as f:
            data = json.load(f)
        if markup is not None:
            inline_keyboard = []
            for row in markup.keyboard:
                row_buttons = []
                for but in row:
                    button_dict = {
                        'text': but.text,
                        'url': but.url
                    }
                    row_buttons.append(button_dict)
                inline_keyboard.append(row_buttons)
            data["markup"] = inline_keyboard
        else:
            data["markup"] = None
        with open('database/info_transmitir.json', 'w') as f:
            json.dump(data, f, indent=4)
    def zerar_infos():
        with open('database/info_transmitir.json', 'r') as f:
            data = json.load(f)
        data["texto"] = None
        data["photo"] = None
        data["markup"] = None
        with open('database/info_transmitir.json', 'w') as f:
            json.dump(data, f, indent=4)
class Admin():
    def total_users():
        with open('database/users.json', 'r') as f:
            data = json.load(f)
        q = 0
        for i in data["users"]:
            q +=1
        return q
    def verificar_admin(id):
        with open('database/admins.json', 'r') as f:
            data = json.load(f)
        for admin in data["admins"]:
            if int(admin["id"]) == int(id):
                return True
            pass
        return False
    def add_admin(id):
        with open('database/admins.json', 'r') as f:
            data = json.load(f)
        data["admins"].append({"id": int(id)})
        with open('database/admins.json', 'w') as f:
            json.dump(data, f, indent=4)
        return True
    def quantidade_admin():
        with open('database/admins.json', 'r') as f:
            data = json.load(f)
        quantity = 0
        for admin in data["admins"]:
            quantity +=1
        return quantity
    def listar_admins():
        with open('database/admins.json', 'r') as f:
            data = json.load(f)
        adm_list = '<b>👮 LISTA DE ADMINS:</b> 🚨\n\n'
        for admin in data["admins"]:
            adm_list += f'\n<b>ADMIN ID</b>: <code>{admin["id"]}</code>'
        return adm_list
    def remover_admin(id):
        with open('database/admins.json', 'r') as f:
            data = json.load(f)
        for admin in data["admins"]:
            if int(admin["id"]) == int(id):
                data["admins"].remove(admin)
                with open('database/admins.json', 'w') as f:
                    json.dump(data, f, indent=4)
                return True
            pass
class Textos():
    def start(message):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        if str(message.chat.id).startswith('-'):
            id = message.from_user.id
            first_name = message.from_user.first_name
            username = message.from_user.username
        link_afiliado = f'https://t.me/{CredentialsChange.user_bot()}?start={message.chat.id}'
        saldo = InfoUser.saldo(id)
        pontos_indicacao = InfoUser.pontos_indicacao(id)
        quantidade_afiliados = InfoUser.quantidade_afiliados(id)
        quantidade_compras = InfoUser.total_compras(id)
        pix_inseridos = f'{InfoUser.pix_inseridos(id):.2f}'
        gifts_resgatados = f'{InfoUser.gifts_resgatados(id):.2f}'
        pais = InfoApi.pegar_pais(InfoUser.pegar_pais_atual(message.chat.id))
        with open('textos/start.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{link_afiliado}', f'{link_afiliado}').replace('{saldo}', f'{saldo:.2f}').replace('{pontos_indicacao}', f'{pontos_indicacao}').replace('{quantidade_afiliados}', f'{quantidade_afiliados}').replace('{quantidade_compras}', f'{quantidade_compras}').replace('{pix_inseridos}', f'{pix_inseridos}').replace('{gifts_resgatados}', f'{gifts_resgatados}').replace('{pais}', f'{pais}')
        return texto
    def perfil(message):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        link_afiliado = f'https://t.me/{CredentialsChange.user_bot()}?start={message.chat.id}'
        saldo = InfoUser.saldo(id)
        pontos_indicacao = InfoUser.pontos_indicacao(id)
        quantidade_afiliados = InfoUser.quantidade_afiliados(id)
        quantidade_compras = InfoUser.total_compras(id)
        pix_inseridos = f'{InfoUser.pix_inseridos(id):.2f}'
        gifts_resgatados = f'{InfoUser.gifts_resgatados(id):.2f}'
        with open('textos/perfil.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{link_afiliado}', f'{link_afiliado}').replace('{saldo}', f'{saldo:.2f}').replace('{pontos_indicacao}', f'{pontos_indicacao}').replace('{quantidade_afiliados}', f'{quantidade_afiliados}').replace('{quantidade_compras}', f'{quantidade_compras}').replace('{pix_inseridos}', f'{pix_inseridos}').replace('{gifts_resgatados}', f'{gifts_resgatados}')
        return texto
    def adicionar_saldo(message):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        link_afiliado = f'https://t.me/{CredentialsChange.user_bot()}?start={message.chat.id}'
        saldo = InfoUser.saldo(id)
        pontos_indicacao = InfoUser.pontos_indicacao(id)
        quantidade_afiliados = InfoUser.quantidade_afiliados(id)
        quantidade_compras = InfoUser.total_compras(id)
        pix_inseridos = f'{InfoUser.pix_inseridos(id):.2f}'
        gifts_resgatados = f'{InfoUser.gifts_resgatados(id):.2f}'
        with open('textos/adicionar_saldo.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{link_afiliado}', f'{link_afiliado}').replace('{saldo}', f'{saldo:.2f}').replace('{pontos_indicacao}', f'{pontos_indicacao}').replace('{quantidade_afiliados}', f'{quantidade_afiliados}').replace('{quantidade_compras}', f'{quantidade_compras}').replace('{pix_inseridos}', f'{pix_inseridos}').replace('{gifts_resgatados}', f'{gifts_resgatados}')
        return texto
    def pix_manual(message):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        saldo = InfoUser.saldo(id)
        deposito_minimo = f'{CredentialsChange.InfoPix.deposito_minimo_pix():.2f}'
        with open('textos/pix_manual.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{saldo}', f'{saldo:.2f}').replace('{deposito_minimo}', f'{deposito_minimo}')
        return texto
    def pix_automatico(message, pix_copia_cola, expiracao, id_pagamento, valor):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        saldo = InfoUser.saldo(id)
        deposito_minimo = f'{CredentialsChange.InfoPix.deposito_minimo_pix():.2f}'
        pix_inseridos = f'{InfoUser.pix_inseridos(id):.2f}'
        with open('textos/pix_automatico.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{saldo}', f'{saldo:.2f}').replace('{pix_inseridos}', f'{pix_inseridos}').replace('{pix_copia_cola}', f'{pix_copia_cola}').replace('{expiracao}', f'{expiracao}').replace('{id_pagamento}', f'{id_pagamento}').replace('{valor}', f'{valor}').replace('{deposito_minimo}', f'{deposito_minimo}')
        return texto
    def pagamento_expirado(message, id_pagamento, valor):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        link_afiliado = f'https://t.me/{CredentialsChange.user_bot()}?start={message.chat.id}'
        saldo = InfoUser.saldo(id)
        with open('textos/pagamento_expirado.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{link_afiliado}', f'{link_afiliado}').replace('{saldo}', f'{saldo:.2f}').replace('{id_pagamento}', f'{id_pagamento}').replace('{valor}', f'{valor}')
        return texto
    def pagamento_aprovado(message, id_pagamento, valor):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        link_afiliado = f'https://t.me/{CredentialsChange.user_bot()}?start={message.chat.id}'
        saldo = InfoUser.saldo(id)
        with open('textos/pagamento_aprovado.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{link_afiliado}', f'{link_afiliado}').replace('{saldo}', f'{saldo:.2f}').replace('{id_pagamento}', f'{id_pagamento}').replace('{valor}', f'{valor}')
        return texto
    def menu_comprar(message):
        first_name = message.chat.first_name
        username = message.chat.username
        id = message.chat.id
        link_afiliado = f'https://t.me/{CredentialsChange.user_bot()}?start={message.chat.id}'
        saldo = InfoUser.saldo(id)
        pontos_indicacao = InfoUser.pontos_indicacao(id)
        quantidade_afiliados = InfoUser.quantidade_afiliados(id)
        quantidade_compras = InfoUser.total_compras(id)
        pix_inseridos = InfoUser.pix_inseridos(id)
        gifts_resgatados = InfoUser.gifts_resgatados(id)
        with open('textos/menu_comprar.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{first_name}', f'{first_name}').replace('{username}', f'@{username}').replace('{id}', f'{id}').replace('{link_afiliado}', f'{link_afiliado}').replace('{saldo}', f'{saldo:.2f}').replace('{pontos_indicacao}', f'{pontos_indicacao}').replace('{quantidade_afiliados}', f'{quantidade_afiliados}').replace('{quantidade_compras}', f'{quantidade_compras}').replace('{pix_inseridos}', f'{pix_inseridos}').replace('{gifts_resgatados}', f'{gifts_resgatados}')
        return texto
    def exibir_servico(message, servico, valor, pais, count):
        saldo = InfoUser.saldo(message.chat.id)
        with open('textos/exibir_servico.txt', 'r') as f:
            texto = f.read()
        with open('database/notas.json', 'r') as f:
            data = json.load(f)
        notas_disp = []
        for nota in data["nota"]:
            notas_disp.append(nota["texto"])
        if len(notas_disp) == 0:
            notas_disp = ['Esse bot não tem notas salvas.']
        nota = random.choice(notas_disp)
        texto = texto.replace('{servico}', f'{servico}').replace('{valor}', f'{float(valor):.2f}').replace('{pais}', f'{pais}').replace('{saldo}', f'{float(saldo):.2f}').replace('{count}', f'{count}').replace('{nota}', f'{nota}')
        return texto
    def mensagem_comprou(message, nome, numero, operadora, valor):
        if message.from_user.is_bot:
            saldo = InfoUser.saldo(message.chat.id)
        else:
            saldo = InfoUser.saldo(message.from_user.id)
        with open('textos/mensagem_comprou.txt', 'r') as f:
            texto = f.read()
        texto = texto.replace('{nome}', f'{nome}').replace('{valor}', f'{valor}').replace('{saldo}', f'{float(saldo):.2f}').replace('{numero}', f'{numero}').replace('{operadora}', f'{operadora}').replace('\\n', '\n')
        return texto
    def termos(message):
        with open('textos/termos.txt', 'r') as f:
            txt = f.read()
        return txt
    def ajuda(message):
        with open('textos/ajuda.txt', 'r') as f:
            txt = f.read()
        return txt
    def id(message):
        with open('textos/id.txt', 'r') as f:
            d = f.read()
            d = d.replace('{id}', f'{message.chat.id}')
        return d
    def afiliados(message):
        with open('textos/afiliados.txt', 'r') as f:
            d = f.read()
        ind = InfoUser.quantidade_afiliados(message.chat.id)
        per = AfiliadosInfo.porcentagem_por_indicacao()
        gan = f'{float(InfoUser.pontos_indicacao(message.chat.id)):.2f}'
        gan = str(gan).replace('.', ',')
        lin = f'https://t.me/{CredentialsChange.user_bot()}?start={message.chat.id}'
        texto = d.replace('{ind}', f'{ind}').replace('{per}', f'{per}').replace('{gan}', f'{gan}').replace('{lin}', f'{lin}')
        return texto
    def saldo(message):
        saldo = f'{float(InfoUser.saldo(message.chat.id)):.2f}'
        with open('textos/saldo.txt', 'r') as f:
            d = f.read()
            d = d.replace('{saldo}', f'{saldo}')
        return d
    def metodos():
        with open('textos/metodos.txt', 'r') as f:
            texto = f.read()
        return texto
class MudarTexto():
    def start(texto):
        with open('textos/start.txt', 'w') as f:
            f.write(texto)
    def perfil(texto):
        with open('textos/perfil.txt', 'w') as f:
            f.write(texto)
    def adicionar_saldo(texto):
        with open('textos/adicionar_saldo.txt', 'w') as f:
            f.write(texto)
    def pix_manual(texto):
        with open('textos/pix_manual.txt', 'w') as f:
            f.write(texto)
    def pix_automatico(texto):
        with open('textos/pix_automatico.txt', 'w') as f:
            f.write(texto)
    def pagamento_expirado(texto):
        with open('textos/pagamento_expirado.txt', 'w') as f:
            f.write(texto)
    def pagamento_aprovado(texto):
        with open('textos/pagamento_aprovado.txt', 'w') as f:
            f.write(texto)
    def menu_comprar(texto):
        with open('textos/menu_comprar.txt', 'w') as f:
            f.write(texto)
    def exibir_servico(texto):
        with open('textos/exibir_servico.txt', 'w') as f:
            f.write(texto)
    def mensagem_comprou(texto):
        with open('textos/mensagem_comprou.txt', 'w') as f:
            f.write(texto)
    def termos(texto):
        with open('textos/termos.txt', 'w') as f:
            f.write(texto)
    def ajuda(texto):
        with open('textos/ajuda.txt', 'w') as f:
            f.write(texto)
    def id(texto):
        with open('textos/id.txt', 'w') as f:
            f.write(texto)
    def afiliados(texto):
        with open('textos/afiliados.txt', 'w') as f:
            f.write(texto)
    def saldo(texto):
        with open('textos/saldo.txt', 'w') as f:
            f.write(texto)
    def metodos(texto):
        with open('textos/metodos.txt', 'w') as f:
            f.write(texto)
class Botoes():
    def comprar():
        with open('botoes/comprar.txt', 'r') as f:
              return f.read()
    def perfil():
        with open('botoes/perfil.txt', 'r') as f:
            return f.read()
    def addsaldo():
        with open('botoes/addsaldo.txt', 'r') as f:
            return f.read()
    def suporte():
        with open('botoes/suporte.txt', 'r') as f:
            return f.read()
    def voltar():
        with open('botoes/voltar.txt', 'r') as f:
            return f.read()
    def comprar_login():
        with open('botoes/comprar_loguin.txt', 'r') as f:
            return f.read()
    def pesquisar_numero():
        with open('botoes/pesquisar.txt', 'r') as f:
            return f.read()
    def pix_manual():
        with open('botoes/pix_manual.txt', 'r') as f:
            return f.read()
    def pix_automatico():
        with open('botoes/pix_automatico.txt', 'r') as f:
            return f.read()
    def download_historico():
        with open('botoes/download_historico.txt', 'r') as f:
            return f.read()
    def trocar_pontos_por_saldo():
        with open('botoes/trocar_pontos_por_saldo.txt', 'r') as f:
            return f.read()
    def paises():
        with open('botoes/paises.txt', 'r') as f:
            return f.read()
    def aguardando_pagamento():
        try:
            with open('botoes/aguardando_pagamento.txt', 'r') as f:
                return f.read()
        except:
            with open('botoes/aguardando_pagamnto.txt', 'w') as f:
                f.write('⏰ AGUARDANDO PAGAMENTO')
                return '⏰ AGUARDANDO PAGAMENTO'
class MudarBotao():
    def paises(texto):
        with open('botoes/paises.txt', 'w') as f:
            f.write(texto)
    def comprar(texto):
        with open('botoes/comprar.txt', 'w') as f:
            f.write(texto)
    def perfil(texto):
        with open('botoes/perfil.txt', 'w') as f:
            f.write(texto)
    def addsaldo(texto):
        with open('botoes/addsaldo.txt', 'w') as f:
            f.write(texto)
    def suporte(texto):
        with open('botoes/suporte.txt', 'w') as f:
            f.write(texto)
    def voltar(texto):
        with open('botoes/voltar.txt', 'w') as f:
            f.write(texto)
    def comprar_login(texto):
        with open('botoes/comprar_login.txt', 'w') as f:
            f.write(texto)
    def pix_manual(texto):
        with open('botoes/pix_manual.txt', 'w') as f:
            f.write(texto)
    def pix_automatico(texto):
        with open('botoes/pix_automatico.txt', 'w') as f:
            f.write(texto)
    def download_historico(texto):
        with open('botoes/download_historico.txt', 'w') as f:
            f.write(texto)
    def trocar_pontos_por_saldo(texto):
        with open('botoes/trocar_pontos_por_saldo.txt', 'w') as f:
            f.write(texto)
    def aguardando_pagamento(texto):
        with open('botoes/aguardando_pagamento.txt', 'w') as f:
            f.write(texto)
class Log():
    def destino_log_registro():
        with open('settings/destino_logs.json', 'r') as f:
            data = json.load(f)
        return data["log-registro"]
    def destino_log_compra():
        with open('settings/destino_logs.json', 'r') as f:
            data = json.load(f)
        return data["log-compra"]
    def destino_log_recarga():
        with open('settings/destino_logs.json', 'r') as f:
            data = json.load(f)
        return data["log-recarga"]
    def destino_log_recebeusms():
        with open('settings/destino_logs.json', 'r') as f:
            data = json.load(f)
        return data["log-recebeu-sms"]
    def destino_log_cancelousms():
        with open('settings/destino_logs.json', 'r') as f:
            data = json.load(f)
        return data["log-cancelou-sms"]
    def log_registro(message):
        with open('log/registro.txt', 'r') as f:
            txt = f.read()
        if message == None:
            return txt
        id = message.chat.id
        name = message.chat.first_name
        username = message.chat.username
        link = f'https://t.me/{username}'
        texto = txt.replace('{id}', f'{id}').replace('{name}', f'{name}').replace('{username}', f'@{username}').replace('{link}', f'{link}').replace('\\n', '\n')
        return texto
    def log_compra(chat_id, nome, numero, operadora, valor):
        with open('log/compra.txt', 'r') as f:
            texto = f.read()
        saldo = InfoUser.saldo(chat_id)
        texto = texto.replace('{id}', f'{chat_id}').replace('{servico}', f'{nome}').replace('{valor}', f'{float(valor):.2f}').replace('{saldo}', f'{saldo:.2f}').replace('{numero}', f'{numero}').replace('{operadora}', f'{operadora}').replace('\\n', '\n')
        return texto
    def log_recarga(message, id_pagamento, valor):
        with open('log/recarga.txt', 'r') as f:
            txt = f.read()
        if message == None:
            return txt
        id = message.chat.id
        name = message.chat.first_name
        username = message.chat.username
        link = f'https://t.me/{username}'
        data = ViewTime.data_atual()
        hora = ViewTime.hora_atual()
        saldo = InfoUser.saldo(message.chat.id)
        texto = txt.replace('{id}', f'{id}').replace('{name}', f'{name}').replace('{username}', f'@{username}').replace('{link}', f'{link}').replace('{data}', f'{data}').replace('{hora}', f'{hora}').replace('{id_pagamento}', f'{id_pagamento}').replace('{valor}', f'{float(valor):.2f}').replace('{saldo}', f'{float(saldo):.2f}').replace('\\n', '\n')
        return texto
class MudarLog():
    def log_registro(txt):
        with open('log/registro.txt', 'w') as f:
            f.write(txt)
    def log_compra(txt):
        with open('log/compra.txt', 'w') as f:
            f.write(txt)
    def log_recarga(txt):
        with open('log/recarga.txt', 'w') as f:
            f.write(txt)
class CriarPix():
    def CriarPixGn(message, valor):
        response = gerar_cobranca.gerar_pix(f'{float(valor):.2f}', message.chat.id)
        locationId = response["locationId"]
        pix_qr = response["code"]
        link_pag = response["link"]
        txid = response["txid"]
        return locationId, pix_qr, link_pag, txid
    def VerificarPixGn(txid):
        params = {
            'txid': txid
            }
        response =  gn.pix_detail_charge(params=params)
        status = response["status"]
        if status == "CONCLUIDA":
            return True
        else:
            return False
    def CriarPixMp(valor, id):
        sdk = mercadopago.SDK(str(CredentialsChange.InfoPix.token_mp()))
        expiracao_time = CredentialsChange.InfoPix.expiracao()
        expire = datetime.datetime.utcnow() + datetime.timedelta(minutes=int(expiracao_time))
        expire = expire.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        payment_data = {
            "transaction_amount": float(valor),
            "description":f'Recarga de {valor} para {id}',
            "payment_method_id": 'pix',
            "date_of_expiration": f'{expire}',
            "payer": {
                "email": 'teste@gmail.com'
            }
        }
        result = sdk.payment().create(payment_data)
        return result